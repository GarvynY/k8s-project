#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import requests
import json
from bs4 import BeautifulSoup
import re
from elasticsearch import Elasticsearch, helpers

# ============ 配置 ============

# Mastodon 配置
MASTODON_INSTANCE     = "mastodon.au"
MASTODON_ACCESS_TOKEN = "OAe_XIfSurn6S8Cp5RjVlhacOmFLSqI1Pb6w6Zdaog0"
HASHTAGS              = ["AusVotes2025", "auspol", "AusVotes", "Election2025"]
LIMIT                 = 10   # 每个标签请求条数

# Elasticsearch 配置（可通过环境变量覆盖）
ES_HOST  = os.getenv("ES_HOST", "elasticsearch-master.elastic.svc.cluster.local")
ES_PORT  = os.getenv("ES_PORT", "9200")
ES_USER  = os.getenv("ES_USER")    # 若无认证可留空
ES_PASS  = os.getenv("ES_PASS")    # 若无认证可留空
ES_INDEX = os.getenv("ES_INDEX", "mastodon_try")

# 初始化 Elasticsearch 客户端
es_config = {
    "hosts": [f"http://{ES_HOST}:{ES_PORT}"]
}
if ES_USER and ES_PASS:
    es_config["http_auth"] = (ES_USER, ES_PASS)
es = Elasticsearch(**es_config)

# 如果索引不存在，则创建一个最简单的索引
if not es.indices.exists(index=ES_INDEX):
    es.indices.create(index=ES_INDEX)
    print(f"[Info] 已创建 Elasticsearch 索引: {ES_INDEX}")

# ============ 函数定义 ============

def html_to_text(html_content):
    """将 HTML 转为纯文本"""
    soup = BeautifulSoup(html_content or "", 'html.parser')
    for tag in soup(["script", "style"]):
        tag.extract()
    text = soup.get_text(separator=" ")
    return re.sub(r'\s+', ' ', text).strip()

def fetch_tag_timeline(tag, token, limit=10):
    """
    调用 Mastodon API 获取指定标签的 timeline，
    返回不超过 limit 条状态（帖子）的 JSON 列表。
    """
    url = f"https://{MASTODON_INSTANCE}/api/v1/timelines/tag/{tag}"
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    params = {"limit": limit}
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"[错误] 获取 #{tag} 时出错: {e}")
        return []

def index_posts_to_es(posts, tag):
    """
    将抓取到的帖子列表批量写入 Elasticsearch。
    每条文档的 _id 设为 "{tag}_{post_id}" 以避免重复。
    """
    actions = []
    for post in posts:
        doc = {
            "mastodon_id": post.get("id"),
            "tag": tag,
            "acct": post.get("account", {}).get("acct"),
            "created_at": post.get("created_at"),
            "content": html_to_text(post.get("content", "")),
        }
        actions.append({
            "_index": ES_INDEX,
            "_id": f"{tag}_{doc['mastodon_id']}",
            "_source": doc
        })
    if actions:
        helpers.bulk(es, actions)
        print(f"[Info] 已将 {len(actions)} 条 #{tag} 帖子写入 Elasticsearch 索引 '{ES_INDEX}'")

def main():
    for tag in HASHTAGS:
        print(f"\n===== #{tag} 的最新 {LIMIT} 条帖子 =====\n")
        posts = fetch_tag_timeline(tag, MASTODON_ACCESS_TOKEN, LIMIT)
        if not posts:
            print("（未获取到任何帖子）")
            continue

        for i, post in enumerate(posts, 1):
            created = post.get("created_at", "")
            acct    = post.get("account", {}).get("acct", "")
            content = html_to_text(post.get("content", ""))
            print(f"帖子 {i}:")
            print(f"  ID       : {post.get('id')}")
            print(f"  用户     : {acct}")
            print(f"  创建时间 : {created}")
            print(f"  内容     : {content}\n")

        # 抓取完成后写入 Elasticsearch
        index_posts_to_es(posts, tag)

    print("Done.")

if __name__ == "__main__":
    main()