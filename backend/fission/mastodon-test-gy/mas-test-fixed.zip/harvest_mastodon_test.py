import os
import requests
import json

def main():
    # 从环境变量读取 Token
    token = "cDWlSYHFFEPxIFpkrTf2ss5kAB7hOekUQ7DY3dglm4E"
    url = "https://mastodon.social/api/v1/timelines/public?limit=5"
    headers = {"Authorization": f"Bearer {token}"}

    resp = requests.get(url, headers=headers, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    # 输出 JSON（Fission 会把 stdout 当作 HTTP Response Body）
    print(json.dumps(data, indent=2))

if __name__ == "__main__":
    main()

