#!/bin/sh
pip install -r requirements.txt -t .

